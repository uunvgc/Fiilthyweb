const enterBtn = document.getElementById("enter-btn");
const viralBtn = document.getElementById("viral-btn");
const clickCountEl = document.getElementById("click-count");

async function updateClicks() {
  const res = await fetch("/api/click");
  const data = await res.json();
  clickCountEl.textContent = data.clicks;
}

enterBtn.addEventListener("click", async () => {
  alert("🚀 Welcome to the FiiLTHY world! Hold tight…");
  await fetch("/api/click"); // Track click
});

viralBtn.addEventListener("click", async () => {
  const shareText = "🔥 Check out FiiLTHY! The wildest app online: https://yourapp.com 🔥";
  if (navigator.share) {
    navigator.share({ text: shareText }).catch(console.error);
  } else {
    prompt("Copy and share this link!", shareText);
  }
  await fetch("/api/click"); // Track share click
});

// Update counter every second
setInterval(updateClicks, 1000);
updateClicks();

// Neon flicker effect
setInterval(() => {
  const h1 = document.querySelector("h1");
  h1.style.textShadow = Math.random() > 0.5 ? "0 0 15px #ff00ff, 0 0 30px #ff0055" : "0 0 5px #ff0055";
}, 500);
