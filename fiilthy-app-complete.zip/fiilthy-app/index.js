const express = require("express");
const path = require("path");
const app = express();

app.use(express.static(path.join(__dirname, "public")));

let clickCount = 0; // In-memory counter

app.get("/api/click", (req, res) => {
  clickCount++;
  res.json({ clicks: clickCount });
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🔥 FiiLTHY IS LIVE on port ${PORT}`);
});